#ifndef TYPES_H
#define TYPES_H

#include <array>
#include <cstdint>
#include <cstdio>

#ifndef M_PIf
#define M_PIf static_cast<f32>(M_PI)
#endif

#define INLINE __attribute__((always_inline))
// #define INLINE

using u8 = u_int8_t;
using u16 = u_int16_t;
using u32 = u_int32_t;
using u64 = u_int64_t;
using usize = size_t;

using i8 = int8_t;
using i16 = int16_t;
using i32 = int32_t;
using i64 = int64_t;
using isize = ssize_t;

using f32 = float;
using f64 = double;

template<typename T>
using ptr = T const*;

template<typename T>
using ptr_mut = T*;

template<typename T>
using ref = T const&;

template<typename T>
using ref_mut = T&;

template<typename T, size_t N>
using array = std::array<T, N>;

#include <cxxabi.h>

inline const char* demangle(const char *s) {
    return abi::__cxa_demangle(s, 0, 0, NULL);
}

template<typename T>
std::string type_name() {
    return demangle(typeid(T).name());
}

#endif //TYPES_H
