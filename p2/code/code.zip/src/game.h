//
// Created by may on 05/10/25.
//

#ifndef GAME_H
#define GAME_H
#include "renderer.h"
#include "resource_store.h"
#include "scene.h"

#ifndef M_PIf
#define M_PIf static_cast<f32>(M_PI)
#endif

class Game {
public:
    ResourceStore resource_store{};
    Scene scene{};
    FrameBuffer frame_buffer;


    explicit Game(FrameBuffer&& frame_buffer) : frame_buffer(std::move(frame_buffer)) {}

    virtual void update(f32 delta, f64 time){}

    void render() {
        Renderer::render(this->frame_buffer, this->scene, this->resource_store);
    }

    virtual ~Game() = default;
};

class HaloGame final : public Game {
public:
    explicit HaloGame(FrameBuffer&& frame_buffer) : Game(std::move(frame_buffer)) {
        auto halo = scene.add_object(Object::load("../assets/halo/spartan_armour_mkv_-_halo_reach.obj", resource_store));
        scene[halo].m_position.z() = 0;

        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});

        scene.m_lights[0].color = {1, 0.1, 0.1};
        scene.m_lights[1].color = {0.1, 1, 0.1};
        scene.m_lights[2].color = {0.1, 0.1, 1};

        scene.m_lights[0].intensity = 20;
        scene.m_lights[1].intensity = 20;
        scene.m_lights[2].intensity = 20;

        scene.m_lights[3].position_or_direction = {1,1,1};
        scene.m_lights[3].color = {1,1,1};
        scene.m_lights[3].global = true;
        scene.m_lights[3].intensity = 0.5;
    }

    void update(f32 delta, f64 time) override {

        auto max_time = 300.f;
        auto percent = static_cast<f32>(time) / max_time;

        scene.m_camera.target = Vector3<f32>{0, static_cast<float>(-1.5 - std::sin(percent * M_PIf) * 0.5), 0};
        // scene.m_camera.position.y() = 2-std::sin(percent * M_PIf)*3;
        scene.m_camera.position.z() = std::cos(percent * M_PIf * 2)*7;///(1.f+std::sin(percent * M_PIf)*0.3f);
        scene.m_camera.position.x() = std::sin(percent * M_PIf * 2)*7;///(1.f+std::sin(percent * M_PIf)*0.3f);

        const auto scale = 4.f;
        scene.m_lights[0].position_or_direction.x() = std::sin(percent * M_PIf * 2)*scale;
        scene.m_lights[0].position_or_direction.z() = std::cos(percent * M_PIf * 2)*-scale;

        scene.m_lights[1].position_or_direction.y() = std::sin(percent*2 * M_PIf * 2)*scale;
        scene.m_lights[1].position_or_direction.z() = std::cos(percent*2 * M_PIf * 2)*-scale;

        scene.m_lights[2].position_or_direction.y() = std::sin(percent*3 * M_PIf * 2)*scale;
        scene.m_lights[2].position_or_direction.x() = std::cos(percent*3 * M_PIf * 2)*-scale;
    }
};

class BrickGame final : public Game {
public:
    explicit BrickGame(FrameBuffer&& frame_buffer) : Game(std::move(frame_buffer)) {
        const auto brick = scene.add_object(Object::load("../assets/bricks/Mauerrest_C.obj", resource_store));
        scene[brick].m_position.y() -= 10;
        // scene[brick].m_scale.x() = 0.2;
        // scene[brick].m_scale.y() = 0.2;
        // scene[brick].m_scale.z() = 0.2;

        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});

        scene.m_lights[0].color = {1, 0.03, 0.03};
        scene.m_lights[1].color = {0.03, 1, 0.03};
        scene.m_lights[2].color = {0.03, 0.03, 1};

        scene.m_lights[0].intensity = 50;
        scene.m_lights[1].intensity = 50;
        scene.m_lights[2].intensity = 50;

        scene.m_lights[3].position_or_direction = {-1,1,-1};
        scene.m_lights[3].color = {1,1,1};
        scene.m_lights[3].global = true;
        scene.m_lights[3].intensity = 0.1;

        scene.m_camera.target = {0, 0, 0};
    }

    void update(f32 delta, f64 time) override {
        const auto max_time = 300.f;
        const auto percent = static_cast<f32>(time) / max_time;

        scene.m_camera.target = {0, 0, 0};
        scene.m_camera.position.z() = std::sin(std::sin(percent*M_PIf*2) * M_PIf/4+M_PIf)*40;
        scene.m_camera.position.x() = std::cos(std::sin(percent*M_PIf*2) * M_PIf/4+M_PIf)*40;

        const auto scale = 3.f;
        scene.m_lights[0].position_or_direction.y() = -2;
        scene.m_lights[0].position_or_direction.x() = std::sin(percent * M_PIf * 2)*scale/1.7f;
        scene.m_lights[0].position_or_direction.z() = std::cos(percent * M_PIf * 2)*-scale/1.7f;

        scene.m_lights[1].position_or_direction.y() = -2+std::sin(percent*2 * M_PIf * 2)*scale/1.7f;
        scene.m_lights[1].position_or_direction.z() = std::cos(percent*2 * M_PIf * 2)*-scale/1.7f;

        scene.m_lights[2].position_or_direction.y() = -2+std::sin(percent*3 * M_PIf * 2)*scale;
        scene.m_lights[2].position_or_direction.x() = std::cos(percent*3 * M_PIf * 2)*-scale;
    }
};

class TestGame final : public Game {
public:
    explicit TestGame(FrameBuffer&& frame_buffer) : Game(std::move(frame_buffer)) {
        const auto brick = scene.add_object(Object::load("../assets/brick/brick.obj", resource_store));
        // scene[brick].m_position.x() = 0.5;
        // scene[brick].m_position.y() = 0.5;
        // scene[brick].m_position.z() = 0.5;
        // scene[brick].m_scale.x() = 0.5;
        // scene[brick].m_scale.y() = 0.5;
        // scene[brick].m_scale.z() = 0.5;

        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});
        scene.m_lights.emplace_back(Light{});

        scene.m_lights[0].color = {1, 0.03, 0.03};
        scene.m_lights[1].color = {0.03, 1, 0.03};
        scene.m_lights[2].color = {0.03, 0.03, 1};

        scene.m_lights[0].intensity = 15;
        scene.m_lights[1].intensity = 15;
        scene.m_lights[2].intensity = 15;

        scene.m_lights[3].position_or_direction = {-1,1,-1};
        scene.m_lights[3].color = {1,1,1};
        scene.m_lights[3].global = true;
        scene.m_lights[3].intensity = 0.1;

        scene.m_camera.target = {0, 0, 0};
    }

    void update(f32 delta, f64 time) override {
        const auto max_time = 300.f;
        const auto percent = static_cast<f32>(time) / max_time;

        scene.m_camera.target = {0, 0, 0};
        scene.m_camera.position.y() = 3;
        scene.m_camera.position.z() = std::sin(percent * M_PIf*2)*5;
        scene.m_camera.position.x() = std::cos(percent * M_PIf*2)*5;

        const auto scale = 3.f;
        scene.m_lights[0].position_or_direction.x() = std::sin(percent * M_PIf * 2)*scale;
        scene.m_lights[0].position_or_direction.z() = std::cos(percent * M_PIf * 2)*-scale;

        scene.m_lights[1].position_or_direction.y() = std::sin(percent*2 * M_PIf * 2)*scale;
        scene.m_lights[1].position_or_direction.z() = std::cos(percent*2 * M_PIf * 2)*-scale;

        scene.m_lights[2].position_or_direction.y() = std::sin(percent*3 * M_PIf * 2)*scale;
        scene.m_lights[2].position_or_direction.x() = std::cos(percent*3 * M_PIf * 2)*-scale;
    }
};

#endif //GAME_H
