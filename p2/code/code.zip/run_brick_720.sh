cd build

./rasterizer --scene=test --width=720 --height=480 --write_frames=true 
