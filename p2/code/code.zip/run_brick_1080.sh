cd build

./rasterizer --scene=test --width=1920 --height=1080 --write_frames=true
